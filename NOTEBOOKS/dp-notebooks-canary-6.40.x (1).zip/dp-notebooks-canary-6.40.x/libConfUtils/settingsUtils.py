# -*- coding: utf-8 -*-

import requests
import json
import math

requestTimeOut = 10
#
displayLogs =  True

def _getRfidSettingsByElementId(envDict, elementType, deviceId, mode):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    url = urlBase + 'statemachine-api-configuration/rest/infra/' + elementType + '/' + deviceId + '/mode/' + mode + '/settings' ;
    if (displayLogs):
        print ("GET : "+url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        raise LookupError(response.content.decode("utf-8"))
    else:
        raise Exception(response.content.decode("utf-8"))

def _getRfidSettingsById(envDict, settingsId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    
    url = urlBase + 'statemachine-api-configuration/rest/infra/settings/' + settingsId;
    if displayLogs:
        print("GET : "+url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        raise LookupError(response.content.decode("utf-8"))
    else:
        raise Exception(response.content.decode("utf-8"))

def _pushRfidSetting(envDict, payload):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    if payload['id'] == payload['parentId']:
        raise NameError('id and parentId should be different: ' + repr(payload))

    print('Push payload ' + repr(payload))
    url = urlBase+'statemachine-api-configuration/rest/infra/settings'
    if displayLogs:
        print("PUT : "+url)
        print(json.dumps(payload,indent=4))
    response = requests.put(url, headers=headers, json=payload, verify=True, timeout=requestTimeOut)
    if response.status_code == 200:
        return response.json()['id']
    else:
        raise Exception(response.content.decode("utf-8"))

def _linkElementToRfidSetting(envDict, elementType, elementId, mode, settingsId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    url = urlBase+'statemachine-api-configuration/rest/infra/' + elementType + '/' + elementId + '/mode/' + mode + '/settings/' + settingsId ;
    if displayLogs:
        print("PUT : "+url)
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 204:
        raise Exception(response.content.decode("utf-8"))
 
def _updateRfidSetting(envDict, elementType, elementId, mode, prop, value):
    payload = {}
    customSettingsId = elementId + '_' + mode

    try:
        customSettings = _getRfidSettingsById(envDict, customSettingsId)
        print('Settings found for id ' + customSettingsId)
        payload['id'] =  customSettings['id']
        payload['name'] =  customSettings['name']
        if 'parentId' in customSettings:
            payload['parentId'] =  customSettings['parentId']
        payload['settings'] = customSettings.get('settings', {})
    except LookupError as error:
        print(repr(error))
        try:
            customSettings = _getRfidSettingsByElementId(envDict, elementType, elementId, mode)
        except LookupError as error:
            print(repr(error))
        if not customSettings or 'code' in customSettings:
            raise LookupError('Could not find current setting for ' + elementId) 
        else:
            print('Settings found for ' + elementType + ' id ' + elementId)
            payload['id'] = customSettingsId
            payload['name'] = payload['id']
            payload['parentId'] = customSettings['id']
            payload['settings'] = {}

    # update
    if value != None:
        payload['settings'][prop] = value
    elif prop in payload['settings']:
        del payload['settings'][prop]

    settingsId = _pushRfidSetting(envDict, payload)
    _linkElementToRfidSetting(envDict, elementType, elementId, mode, settingsId)
    return payload

def getRfidSettingsByDeviceId(envDict, deviceId, mode):
    return _getRfidSettingsByElementId(envDict, 'devices', deviceId, mode)['settingsView']

# TODO: should be moved in Configuration Device API
def updateDeviceRfidSetting(envDict, deviceId, mode, prop, value):
    return _updateRfidSetting(envDict, 'devices', deviceId, mode, prop, value)

def getRfidSettingsByPovId(envDict, povId, mode):
    return _getRfidSettingsByElementId(envDict, 'povs', povId, mode)['settingsView']

# TODO: should be moved in Configuration Device API
def updatePovRfidSetting(envDict, deviceId, mode, prop, value):
    return _updateRfidSetting(envDict, 'povs', deviceId, mode, prop, value)

if __name__ == '__main__':
    envDict = {'urlDP': 'https://dpo-lab01.shopcx.io/', 'urlDPConf': 'https://dpo-lab01.shopcx.io/statemachine-api-configuration/rest/', 'token': 'dGVzdGVyOnRlc3Rpc2xpZmU', 'headers': {'Authorization': 'Basic dGVzdGVyOnRlc3Rpc2xpZmU'}}
    print() 
    result = updateDeviceRfidSetting(envDict, '1680168386', 'HSPN', 'toto', 'tutu')
    print('Effective device settings: ' + repr(getRfidSettingsByDeviceId(envDict, '1680168386', 'HSPN')))
    print()
    result = updateDeviceRfidSetting(envDict, '1680168386', 'HSPN', 'toto', None)
    print('Effective device settings: ' + repr(getRfidSettingsByDeviceId(envDict, '1680168386', 'HSPN')))
    print() 
    print("=======================================================")
    print() 
    result = updatePovRfidSetting(envDict, '1WRNXYZ2MiDcL3gPr', 'HSPN', 'toto', 'tutu')
    print('Effective pov settings: ' + repr(getRfidSettingsByPovId(envDict, '1WRNXYZ2MiDcL3gPr', 'HSPN')))
    print()
    result = updatePovRfidSetting(envDict, '1WRNXYZ2MiDcL3gPr', 'HSPN', 'toto', None)
    print('Effective pov settings: ' + repr(getRfidSettingsByPovId(envDict, '1WRNXYZ2MiDcL3gPr', 'HSPN')))
    
    