# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 19:08:29 2018

@author: jlinotte
"""


import requests
import json
import math
#import pprint as pprint
import random
import time

requestTimeOut = 10
#
displayLogs =  True
#%%
def getHelp():
    print ('Available functions:')
    print ('    getAllDevices(envDict)')
    print ('    getDevicesOfPremise(envDict)')
    print ('    getDevicesOfLocation(envDict, modelsSelection=None, locationId=None)')
    print ('    getDeviceById(envDict,deviceId)')
    print ('    deleteDeviceById(envDict,deviceId)')
    print ('    deleteDeviceNPovById(envDict,deviceId)')
    print ('    refreshDevice(envDict,deviceId)')
    print ('    createPowerNode(envDict,pnMac)')
    print ('    transform2PowerNode(envDict,pnId)')
    print ('    createPOS(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, deviceModel)')
    print ('    createXPT(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, deviceModel)')
    print ('    getDeviceModels(envDict)')
    print ('    getDeviceModes(envDict)')
    print ('    getModesOfModel(envDict,modelId)')
    print ('    addModeToModel(envDict,modelId,modeId)')

    print ('    linkDeviceToPov(envDict,povId,deviceId)')
    print ('    disableDevice(envDict,deviceId)')
    print ('    enableDevice(envDict,deviceId)')

#%% get all devices of the premise (paginated)
def getAllDevices(envDict):

    allDevices_json = ''
    if (envDict ==''):
        return allDevices_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')

    whatToDO = '/infra/devices'
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    allDevices_json = response.json() #réponse sous format JSON
    if response.ok:
        print ("Devices")
        allDevices_json = response.json()
        print(json.dumps(allDevices_json,indent=4))

    # create a dict {id:json device file}
    return allDevices_json

    #%% get all devices of the premise (paginated)
def getDevicesOfPremise(envDict, modelsSelection=None):
    allDevices_json = ''
    if (envDict ==''):
        return allDevices_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    print ('PremiseId: ' + repr(PremiseId))
    
    return getDevicesOfLocation(envDict, modelsSelection, PremiseId)

def getDevicesOfHUB(envDict, modelsSelection=None):
    allDevices_json = ''
    if (envDict ==''):
        return allDevices_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'infra/hub/'+ HUB +'/settings'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Devices")
        allDevices_json = response.json()
        print(json.dumps(allDevices_json,indent=4))
    else :
        print("no device found " + response.content.decode("utf-8"))   
        
    return allDevices_json


def getHUBSettings_legacy(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'configuration/hub/'+ HUB
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB legacy settings")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no settings found " + response.content.decode("utf-8"))   
        
    return HUB_json


def getHotspotById(envDict,hsId):
    HS_json = ''
    if (envDict ==''):
        return allDevices_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'configuration/hs/'+ hsId
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HS legacy settings")
        HS_json = response.json()
        print(json.dumps(HS_json,indent=4))
    else :
        print("no HS settings found " + response.content.decode("utf-8"))   
        
    return HS_json


def getLegacyPowerNodeById(envDict,pnId):
    PN_json = ''
    if (envDict ==''):
        return PN_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'configuration/pn/'+ pnId
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("PN legacy settings")
        PN_json = response.json()
        print(json.dumps(PN_json,indent=4))
    else :
        print("no PN settings found " + response.content.decode("utf-8"))   
        
    return PN_json


def setLegacyPowerNodeById(envDict,pnId,PN_json):
    PN_json = ''
    if (envDict ==''):
        return PN_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers2 = envDict.get('headers2')
    #https://dp-showroom.shopcx.io/statemachine-api-configuration/rest/configuration/hub/HUB_SHO_ETSI/pn/999
    whatToDO = 'configuration/pn/'+ pnId +'?pn_id_modified=false'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("PUT " + url)
        print(json.dumps(PN_json,indent=4))

    response = requests.post(url, headers=headers2,json = PN_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("PN legacy settings")
        PN_json = response.json()
        print(json.dumps(PN_json,indent=4))
    else :
        print("no PN settings found " + response.content.decode("utf-8"))   
        
    return PN_json
    #%% get all devices of the premise (paginated)
def getDevicesOfLocation(envDict, modelsSelection=None, locationId=None):
    allDevices_json = ''
    if (envDict ==''):
        return allDevices_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    if not locationId:
        locationId = envDict.get('LocationId')
    
    print ('Location ID: ' + repr(locationId))
      
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')

    queryParam = ''
    if modelsSelection:
        queryParam = '?model=' + '&model='.join(str(x) for x in modelsSelection) 
    whatToDO = 'locations/'+ locationId +'/infra/devices' + queryParam
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Devices")
        allDevices_json = response.json()
        print(json.dumps(allDevices_json,indent=4))
#    else: 
#        print("no device found")
    # create a dict {id:json device file}
    return allDevices_json

#%%
def getDeviceById(envDict,deviceId):

    if deviceId == '':
        return ''
        
    if envDict != '':
        urlDPConf = envDict.get('urlDPConf')
        headers = envDict.get('headers')
        headers2  = envDict.get('headers2')
    else:
        return ''

    device_json = ''
    deviceType_json = ''
    deviceMode_json = ''
    startupmodeDevice_json = ''
    devicePov_json = ''
    devicePovFixture_json = ''
        
    deviceExist = True
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
        print ("ID : " + device_json.get('id'))
        if 'mac' in device_json :
            print ("MAC: " + device_json.get('mac'))
        if 'address' in device_json :
            print ("ADD: " + device_json.get('address'))
    else :
        print("fail" + response.content.decode("utf-8"))
        deviceExist = False
        
    if deviceExist:
      whatToDO = 'infra/devices/'+ deviceId +'/model'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          deviceType_json = response.json() #réponse sous format JSON
          print(deviceId + " model:" + response.content.decode("utf-8"))
      else :
        print("fail model " + response.content.decode("utf-8"))
    
    
    if deviceExist:
      whatToDO = 'infra/devices/'+ deviceId +'/modes'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          deviceMode_json = response.json() #réponse sous format JSON
          print(deviceId + " mode:" + response.content.decode("utf-8"))
      else :
        print("fail modes " + response.content.decode("utf-8"))    
    
    
    if deviceExist and deviceType_json and not deviceMode_json:
      modelId = deviceType_json.get('id')  
      whatToDO = 'infra/device/models/'+ modelId +'/modes'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          deviceModelModes_json = response.json() #réponse sous format JSON
          print(deviceId + " modes of the model:" + response.content.decode("utf-8"))
      else :
        print("fail modes " + response.content.decode("utf-8"))    

    
    povExist = False    
    if deviceExist:
      whatToDO = 'infra/devices/'+ deviceId + '/povs'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          devicePov_json = response.json() #réponse sous format JSON
          print(deviceId + " POV :" + response.content.decode("utf-8"))
          povExist = True
      else :
        print("fail POV" + response.content.decode("utf-8"))    
    
    
    if deviceExist:
      whatToDO = 'infra/devices/'+ deviceId + '/startupmode'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          startupmodeDevice_json = response.json() #réponse sous format JSON
          print(deviceId + " startupmode :" + response.content.decode("utf-8"))
      else :
        print("fail startupmode" + response.content.decode("utf-8"))
    
    
    #TODO get mode setting
    
    # get fixture
    devicePovFixture_json = {}
    if povExist:    
        for elt in devicePov_json:
          if 'id' in elt :
            povID = elt.get('id')
            if povExist:
              whatToDO = 'infra/povs/'+ povID + '/fixture'
              url=urlDPConf+whatToDO
              response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
              if response.ok:   
                  devicePovFixture_json.update({povID :response.json()}) #réponse sous format JSON
                  print(povID + " fixture:" + response.content.decode("utf-8"))
              else :
                  print("fail fixture for POVID " +povID + " : "+ response.content.decode("utf-8"))
    
    #output
    deviceDict  = {'device':device_json,
               'deviceType':deviceType_json,
               'deviceMode':deviceMode_json,
               'deviceStarUpMode':startupmodeDevice_json,
               'devicePov':devicePov_json,
               'devicePovFixtures':devicePovFixture_json}
    
    return deviceDict
#%%
def deleteDeviceById(envDict,deviceId):

    if envDict == '' :
        return
    
    if deviceId == '' :
        return
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2') 
    urlDPConf = envDict.get('urlDPConf')
    # delete links                      
    whatToDO = 'infra/devices/'+ deviceId + '/povs'
    url=urlDPConf+whatToDO
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
            print ("ID : " + deviceId + " pov link deleted")
    else :
        return
    # delete the device
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
            print ("ID : " + deviceId + " deleted")
            
    return
#%%
def deleteDeviceNPovById(envDict,deviceId):

    if envDict == '' :
        return
    
    if deviceId == '' :
        return
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2') 
    urlDPConf = envDict.get('urlDPConf')
    
    deviceExist = True
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
        print ("ID : " + device_json.get('id'))
        if 'mac' in device_json :
            print ("MAC: " + device_json.get('mac'))
        if 'address' in device_json :
            print ("ADD: " + device_json.get('address'))
    else :
        print("fail" + response.content.decode("utf-8"))
        deviceExist = False
        return
    
    povExist = False    
    if deviceExist:
      whatToDO = 'infra/devices/'+ deviceId + '/povs'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          devicePov_json = response.json() #réponse sous format JSON
          print(deviceId + " POV :" + response.content.decode("utf-8"))
          povExist = True
      else :
        print("fail POV" + response.content.decode("utf-8"))    
    else:
        return
    
    if povExist:
        for pov in devicePov_json:
            povId = pov.get('id')
            print ("POV ID : " + pov.get('id'))

            whatToDO = 'infra/povs/'+ povId + '/device'            
            url=urlDPConf+whatToDO
            response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
            if response.ok:
                print ("ID : " + povId + " device link deleted")
            else :
                print ("fail delete device link " + response.content.decode("utf-8"))
            
            whatToDO = 'infra/povs/'+ povId + '/fixture'            
            url=urlDPConf+whatToDO
            response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
            if response.ok:
                print ("ID : " + povId + " fixture link deleted")
            else :
                print ("fail delete fixture link " + response.content.decode("utf-8"))
            
            whatToDO = 'infra/povs/'+ povId
            url=urlDPConf+whatToDO
            response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
            if response.ok:
                print ("ID : " + povId + " deleted")
            else :
                print ("fail delete "+ povId + " "  + response.content.decode("utf-8"))
    
    
    # delete links                      
    whatToDO = 'infra/devices/'+ deviceId + '/povs'
    url=urlDPConf+whatToDO
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
            print ("ID : " + deviceId + " pov link deleted")
    else :
        return
    
    
    
    # delete the device
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
            print ("ID : " + deviceId + " deleted")
            
    return
#%%
def refreshDevice(envDict,deviceId):


    if deviceId == '':
        return ''
        
    if envDict != '':
        urlDPConf = envDict.get('urlDPConf')
        headers = envDict.get('headers')
        headers2  = envDict.get('headers2')
    else:
        return ''

    deviceExist = True
        
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
        
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = device_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        deviceRefeshResponse_json = response.json() #réponse sous format JSON
                                   

    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        deviceRefesh_json = response.json() #réponse sous format JSON
                                 
#%% Create PowerNode
def createPowerNode(envDict,pnMac):


    if envDict == '' :
        return
    
    if pnMac == '' :
        return

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    #hashCode
    pnIdint = 0
    for char in pnMac:
        pnIdint = (((pnIdint << 5) - pnIdint + ord(char) | 0) %  int(math.pow(2, 31) - 1))
    pnId=str(pnIdint)
    
    pnName = 'PN_'+pnMac
    newPn_json = {
      'id':pnId,
      'mac': pnMac,
      'isEnabled': True,
      'name': pnName
    }

    whatToDO = 'infra/devices/'+ pnId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = newPn_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        PnCreate_json = response.json() #réponse sous format JSON
    
    whatToDO = 'infra/devices/mac/'+ pnMac
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
        print ("ID : " + device_json.get('id'))
        pnId = device_json.get('id')
        if 'mac' in device_json :
            print ("MAC: " + device_json.get('mac'))
        if 'address' in device_json :
            print ("ADD: " + device_json.get('address'))
    else :
        print("fail" + response.content.decode("utf-8"))
        deviceExist = False

    # model
    tmp = getDeviceModels(envDict)
    pnModel = ''
    for elt in tmp:
        if (elt.get('id') == "CXI__PN__2.1"):
            pnModel = elt.get('id')
            break ;
        elif  (elt.get('id') == "PNOD__00"):
            pnModel = elt.get('id')
            break ;

    if (len(pnModel)==0):
        print("No model found")
        return
#    pnModel = 'PNOD__00' #'CXI__PN__2.1'
    whatToDO = 'infra/devices/'+ pnId +'/model/' +pnModel
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(pnId + " change model:" + response.content.decode("utf-8"))
    else :
        print("fail change model " + response.content.decode("utf-8"))

    # startUp Mode
    pnStartUpMode = 'HSPN'    
    whatToDO = 'infra/devices/'+ pnId + '/startupmode/' + pnStartUpMode
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(pnId + " put startupmode :" + response.content.decode("utf-8"))
    else :
      print("fail put startupmode" + response.content.decode("utf-8"))

# put all available modes ?
#%%
def transform2PowerNode(envDict,pnId):
#%% transform to PowerNode
    if envDict == '' :
        return
    
    if pnId == '' :
        return

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')

    # model
    pnModel = 'PNOD__00' #'CXI__PN__2.1'
    whatToDO = 'infra/devices/'+ pnId +'/model/' +pnModel
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        #response_json = response.json() #réponse sous format JSON
        print(pnId + " change model:" + response.content.decode("utf-8"))
    else :
        print("fail change model " + response.content.decode("utf-8"))
    
    # startUp Mode
    pnStartUpMode = 'HSPN'    
    whatToDO = 'infra/devices/'+ pnId + '/startupmode/' + pnStartUpMode
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        #startupmodeDevice_json = response.json() #réponse sous format JSON
        print(pnId + " put startupmode :" + response.content.decode("utf-8"))
    else :
        print("fail put startupmode" + response.content.decode("utf-8"))
        
        
#    whatToDO = 'infra/devices/'+pnId +'/mode/HSPN/settings/PN_DEFAULT'
#    url=urlDPConf+whatToDO
#    response = requests.put(url, headers=headers, verify=True)
#    if response.ok:
#        print ("setting HSPN/settings/DEFAULT :  updated")
#    else :
#        print ("fail setting HSPN/settings/DEFAULT" + response.content.decode("utf-8"))

#%% Create XPT
def createXPT(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, deviceModel='IMPINJ__R220__1', startMode='XPOINT'):
    deviceId = _createDevice(envDict, deviceIp, deviceName, deviceId, deviceMac, startMode)
    deviceId = _setDeviceModel(envDict, deviceId, deviceModel)
    return deviceId

#%% Create CONVEYOR
def createCONVEYOR(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, deviceModel='MOJIX__STARFLEX_1', startMode='AUTOMATED_PROCESS'):
    deviceId = _createDevice(envDict, deviceIp, deviceName, deviceId, deviceMac, startMode)
    deviceId = _setDeviceModel(envDict, deviceId, deviceModel)
    return deviceId
#%% Create POS
def createPOS(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, deviceModel='KEONN__ADPY__1', startMode='POS_PAYMENT'):
    deviceId = _createDevice(envDict, deviceIp, deviceName, deviceId, deviceMac, startMode)
    deviceId = _setDeviceModel(envDict, deviceId, deviceModel)
    return deviceId

def getPovsLinkedToDevice(envDict, deviceId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
   
    response = requests.get(urlBase + 'statemachine-api-configuration/rest/infra/devices/' + deviceId + '/povs' , headers=headers, verify=True, timeout=requestTimeOut)
    print('Povs : ', response.status_code)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()

#%% Create XPT
def _setDeviceModel(envDict,deviceId,deviceModel):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/devices/' + deviceId + '/model/' + deviceModel, headers=headers, verify=True, timeout=requestTimeOut)
    print('Device Model: ', response.status_code)
    if response.status_code != 204:
        print('Device Model: ', deviceModel)
        raise Exception(response.content.decode("utf-8"))

    return deviceId

#%% Create Device
def _createDevice(envDict,deviceIp,deviceName,deviceId=None, deviceMac=None, startMode=None):

    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')

    payload = {
      'name': deviceName,
      'address': deviceIp,
      'isEnabled': True
    }

    if not deviceIp:
        raise Exception('Missing Device Ip')
    if not deviceName:
        raise Exception('Missing Device Name')

    if deviceId:
        payload['id'] = deviceId
    if deviceMac:
        payload['mac'] = deviceMac
   
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/devices', headers=headers, json=payload, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))
    
    deviceId = response.json()['id']
    print('Device id: ', deviceId)

    if startMode:
        response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/devices/' + deviceId + '/startupmode/' + startMode, headers=headers, json=payload, verify=True, timeout=requestTimeOut)
        print('Device Default Mode: ' + startMode)
        if response.status_code != 204:
            raise Exception(response.content.decode("utf-8"))

    return deviceId

#%% Create L40
def createL40(envDict,deviceIp,deviceID,deviceName):

    if envDict == '' :
        return
    
    if deviceIp == '' :
        return

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    

    newPOS_json = {
      'id':deviceID,
      'address': deviceIp,
      'isEnabled': True,
      'name': deviceName
    }
    whatToDO = 'infra/devices/'+ deviceID
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = newPOS_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        L40Create_json = response.json() #réponse sous format JSON
    

    # model
    # TODO Check that the model exist
    deviceModel= 'INVENGO__L40__1'
    whatToDO = 'infra/devices/'+ deviceID +'/model/' +deviceModel
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(deviceID + " change model:" + response.content.decode("utf-8"))
    else :
        print("fail change model " + response.content.decode("utf-8"))

    # startUp Mode
    xpStartUpMode = 'HF'    
    whatToDO = 'infra/devices/'+ deviceID + '/startupmode/' + xpStartUpMode
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(deviceID + " put startupmode :" + response.content.decode("utf-8"))
    else :
      print("fail put startupmode" + response.content.decode("utf-8"))
      
      
#    whatToDO = 'infra/devices/'+deviceID +'/mode/HF/settings/HF_DEFAULT'
#    url=urlDPConf+whatToDO
#    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
#    if response.ok:
#        print ("L40 HF/settings/HF_DEFAULT :  updated")
#    else :
#        print ("fail create pos XPOINT/settings/XPOINT_DEFAULT" + response.content.decode("utf-8"))
      
#%% PRINTER
def createPrinter(envDict,printerIp,printerName,printerMac,printerFixture):
    
    cnt = 2
    printerId = 0

    while (cnt>0):
        printerId = (random.randint(1,2147483647)) # 2^31 -1
        #printerId = int(1000*time.time())
        printerDef = getPrinter(envDict,str(printerId))
        if printerDef:
            # unlucky
            cnt = cnt -1
            printerId = 0
        else:
            break

    if printerId == 0:
        print ('Printer ID generation: an error occurs during process')
        return ''
    printerIdStr= str(printerId)
    return _createPrinter(envDict,printerIp,printerIdStr,printerName,printerMac,printerFixture)

def _createPrinter(envDict,printerIp,printerId,printerName,printerMac,printerFixture):

    PrinterCreate_json = '' 
    
    if envDict == '' :
        return PrinterCreate_json
    
    if not printerId:
        return PrinterCreate_json


    if not printerMac:
        printerMac = None
        
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')



    newPrinter_json = {
            'id': printerId,
            'creation': None,
            'name': printerName,
            'uri': printerIp,
            'version': None,
            'rfidTagCode': None,
            'mac': printerMac,
            'fixtureId': printerFixture,
            'isEnabled': True
    }
    whatToDO = 'configuration/printer/'+ str(printerId)
 
    url=urlDPConf+whatToDO
    if displayLogs:
        print("PUT " + url)
        print(json.dumps(newPrinter_json, indent=4, sort_keys=True))
    response = requests.put(url, headers=headers2 ,json = newPrinter_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        try :
            PrinterCreate_json = response.json() #réponse sous format JSON
            if displayLogs:
                print(json.dumps(PrinterCreate_json, indent=4, sort_keys=True))
        except: 
            print("WARN printer created but no json return: " + response.content.decode("utf-8"))
            PrinterCreate_json = newPrinter_json
               
    else :
        print("fail printer create fails " + response.content.decode("utf-8"))
            
    return PrinterCreate_json
#%% getPrinter
def getPrinter(envDict,printerId):

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    Printer_json = '' 
    
    if envDict == '' :
        return Printer_json
    
    if printerId == '' :
        return Printer_json
    
    whatToDO = 'configuration/printer/'+ str(printerId)
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        Printer_json = response.json() #réponse sous format JSON
    else :
        print("fail to get printer " + response.content.decode("utf-8"))
    
    return Printer_json

#%% getPrinters
def getPrintersOfPremise(envDict):

    printersDefinition = ''
    if envDict == '' :
        return printersDefinition
    
    
    #HUB = envDict.get('HUB')
    premiseCode = envDict.get('PremiseCode')
    premiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')    
    
    whatToDO = 'configuration/locations/code/premise/'+ premiseCode +'/printers'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        printersDefinition = response.json() #réponse sous format JSON
        print(premiseId + " printers:" + response.content.decode("utf-8"))
    else :
        print("fail printers " + response.content.decode("utf-8"))  
        
        
    return printersDefinition


#%% deletePrinter
def deletePrinter(envDict,printerId):

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    Printer_json = '' 
    
    if envDict == '' :
        return Printer_json
    
    if printerId == '' :
        return Printer_json

    whatToDO = 'configuration/printer/'+ str(printerId) + '/fixture'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("DELETE " + url)
    response = requests.delete(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        #Printer_json = response.json() #réponse sous format JSON
        Printer_json =''
    else :
        print("fail to delete printer link" + response.content.decode("utf-8"))
 
    whatToDO = 'configuration/printer/'+ str(printerId)
    url=urlDPConf+whatToDO
    if displayLogs:
        print("DELETE " + url)
    response = requests.delete(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        #Printer_json = response.json() #réponse sous format JSON
        Printer_json =''        
    else :
        print("fail to delete printer " + response.content.decode("utf-8"))
        
    return Printer_json



#%% get device models
def getDeviceModels(envDict):
    if envDict == '' :
        return
    
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'infra/device/models'
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" models:" + response.content.decode("utf-8"))
    else :
        print("fail to get models " + response.content.decode("utf-8"))
    return response.json()
        
#%%
def createOrUpdateDeviceModel(envDict,brand,model,version,type,mode):
    if envDict == '' :
        return
    id = brand + "_" +model+"_"+version
    deviceModel_json = {
            "id":id,
            "name":model,
            "brand":brand,
            "version":version
    }
    
    urlDPConf = envDict.get('urlDPConf')
    headers2 = envDict.get('headers2')
    headers = envDict.get('headers')

    whatToDO = 'infra/device/models'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = deviceModel_json  ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" models:" + response.content.decode("utf-8"))
    else :
        print("fail to get models " + response.content.decode("utf-8"))
 
    
    whatToDO = 'infra/device/models/'+id+'/types/' + type
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers  ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" mode:" + response.content.decode("utf-8"))
    else :
        print("fail to set mode" + response.content.decode("utf-8"))       


    whatToDO = 'infra/device/models/'+id+'/modes/' + mode
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers  ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" mode:" + response.content.decode("utf-8"))
    else :
        print("fail to set mode" + response.content.decode("utf-8"))        
#%% get device modes
def getDeviceModes(envDict):
    if envDict == '' :
        return
    
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'infra/device/modes'
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" modes:" + response.content.decode("utf-8"))
    else :
        print("fail to get modes " + response.content.decode("utf-8"))
#%% get full settings
def getSettings(envDict):
    if envDict == '' :
        return
    
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = '/infra/settings'
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print("infra settings:" + response.content.decode("utf-8"))
    else :
        print("fail to get infra settings " + response.content.decode("utf-8"))
        
#%% get  settings
def getSettingsByName(envDict,settingsName):
    settings = ''
    if envDict == '' :
        return settings
    
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = '/infra/settings/'+settingsName
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print("infra settings:" + response.content.decode("utf-8"))
        settings = response.json()
    else :
        print("fail to get infra settings " + response.content.decode("utf-8"))
        
    return settings
#%% get modes of a model
def getModesOfModel(envDict,modelId):
    
    if envDict == '' :
        return
    
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'infra/device/models/'+ modelId +'/modes'
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(modelId + " modes:" + response.content.decode("utf-8"))
    else :
        print("fail to get modes " + response.content.decode("utf-8"))

#%% 
def addModeToModel(envDict,modelId,modeId):
    
    if envDict == '' :
        return
    
    if modelId == '' :
        return
    
    if modeId == '' :
        return

    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    
    whatToDO = 'infra/device/models/'+ modelId +'/modes/'+modeId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(modelId + " adding mode " +modeId+' '+ response.content.decode("utf-8"))
    else :
        print("fail to add mode " + response.content.decode("utf-8"))
        
        

#%%
def linkDeviceToPov(envDict,povId,deviceId):
    
    if envDict =='':
        return False

    if povId == '':
        return False
    
    if deviceId == '':
        return False
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    whatToDO = 'infra/devices/'+deviceId +'/povs/' + povId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create device link to pov :  updated")
        return True
    else :
        print ("fail create pos link to pov" + response.content.decode("utf-8"))
        return False
    

#%%    
def disableDevice(envDict,deviceId):


    if deviceId == '':
        return
        
    if envDict != '':
        urlDPConf = envDict.get('urlDPConf')
        headers = envDict.get('headers')
        headers2  = envDict.get('headers2')
    else:
        return

    deviceExist = True
        
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
    else :
        print ("fail to get device "+ deviceId + response.content.decode("utf-8"))
        return False
    
    device_json.update({'isEnabled': False})  
    
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = device_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        deviceRefeshResponse_json = response.json() #réponse sous format JSON
    else :
        print ("fail to update device "+ deviceId + response.content.decode("utf-8"))
        return False
    
    return True

#%%
                                   
def enableDevice(envDict,deviceId):

    if deviceId == '':
        return
        
    if envDict != '':
        urlDPConf = envDict.get('urlDPConf')
        headers = envDict.get('headers')
        headers2  = envDict.get('headers2')
    else:
        return

    deviceExist = True
        
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    if displayLogs:
        print ("GET " + url)
        
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        device_json = response.json() #réponse sous format JSON
    else :
        print ("fail to get device "+ deviceId + response.content.decode("utf-8"))
        return False
    
    device_json.update({'isEnabled': True})  
    
    whatToDO = 'infra/devices/'+ deviceId
    url=urlDPConf+whatToDO
    if displayLogs:
        print ("PUT " + url)
    response = requests.put(url, headers=headers2 ,json = device_json , verify=True, timeout=requestTimeOut)
    if response.ok:
        deviceRefeshResponse_json = response.json() #réponse sous format JSON
    else :
        print ("fail to update device "+ deviceId + response.content.decode("utf-8"))
        return False
    
    return True


#%%
def checkIPUnicityOnThePremise(envDict,ipAddress):
    res = {
      'status': True,
      'message': '' 
      }
    
    ipAddress = ipAddress.strip()
     # in printers
    listOfPrinters = getPrintersOfPremise(envDict)
    for printer in listOfPrinters:
        deviceDefinition = getPrinter(envDict,printer.get('id'))
        if (ipAddress == deviceDefinition.get('uri')):
            res['message'] = 'Printer '+ printer.get('id') + ' already uses this IP address'
            res['status'] = False
            return res
        
    # in devices
    listOfDevices = getDevicesOfPremise(envDict)
    for device in listOfDevices:
        deviceDefinition = getDeviceById(envDict,device.get('id'))
        devicepart = deviceDefinition.get('device')
        if (ipAddress == devicepart.get('address')):
            res['message'] = 'Device '+ devicepart.get('id') + ':'+devicepart.get('name') +' already uses this IP address'
            res['status'] = False
    # in hotspots
    hpsn = getHUBSettings_legacy(envDict)
    for settings in hpsn:
        listOfhs = settings.get('hs')
        nbHs = settings.get('hsCount')
        if nbHs > 0 :
            for deviceId in listOfhs:
                HotspotDefinition = getHotspotById(envDict,deviceId)
                if (ipAddress == HotspotDefinition[0].get('readerIp')):
                    res['message'] = 'Hotspot '+ deviceId + ' already uses this IP address'
                    res['status'] = False
                if (ipAddress == HotspotDefinition[0].get('controller').get('ip')):
                    res['message'] = 'Hotspot '+ deviceId + ' already uses this IP address'
                    res['status'] = False
    return res
