# -*- coding: utf-8 -*-
"""
Created on Wed Dec 12 13:18:27 2018

@author: jlinotte
"""

from tkinter import Tk
from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import askopenfilenames
from tkinter.filedialog import asksaveasfilename


displayLogs =  False
#%% Choose a file
def getOneFile(initialdirectory,windowTitle,filtersDefinition):
    root = Tk()
    root.withdraw()
    root.update()
    filename = askopenfilename(initialdir = initialdirectory,title = windowTitle,filetypes = filtersDefinition)
    return filename

#%% Choose multiple files
def getMultipleFiles(initialdirectory,windowTitle,filtersDefinition):
    root = Tk()
    root.withdraw()
    root.update()
    filenames = askopenfilenames(initialdir = initialdirectory,title = windowTitle,filetypes = filtersDefinition)
    lisOfFilenames = list(filenames)
    return lisOfFilenames


#%% Choose a file
def saveOneFile(initialdirectory,defaultName,windowTitle,filtersDefinition):
    root = Tk()
    root.withdraw()
    root.update()
    filename = asksaveasfilename(initialdir = initialdirectory,title = windowTitle,initialfile=defaultName,filetypes = filtersDefinition)
    return filename
#%% get from a menu
#choices = ["aa","bb","cc"]    
def chooseWithMenu(windowTitle,choices):

    master = Tk()
    master.title(windowTitle)
    variable = StringVar(master)
    variable.set(choices[0]) # default value
    w = OptionMenu(master,variable,*choices)
    w.pack()

    def ok():
        master.quit()
        
    button = Button(master, text="Select", command=ok)    
    button.pack()

    mainloop()
    try:
        master.destroy()
        choice=variable.get()
        print (choice)
    except:
        choice = ''
        
    return choice


#%%
def inputWithForm(windowTitle,fields):
    root = Tk()
    
    def fetch(entries):
       root.setvar(name='status',value='ok')
       for entry in entries:
          field = entry[0]
          text  = entry[1].get()
          print('%s: "%s"' % (field, text)) 
          root.setvar(name=str(field),value=text) 
       root.quit()
    
    def cancel():
        root.setvar(name='status',value='ko')
        root.quit()
            
    def makeform(root, fields):
       entries = []
       for field in fields:
          row = Frame(root)
          lab = Label(row, width=15, text=field, anchor='w')
          ent = Entry(row)
          row.pack(side=TOP, fill=X, padx=5, pady=5)
          lab.pack(side=LEFT)
          ent.pack(side=RIGHT, expand=YES, fill=X)
          entries.append((field, ent))
       return entries

#if __name__ == '__main__':

    root.title(windowTitle)

    ents = makeform(root, fields)
    root.bind('<Return>', (lambda event, e=ents: fetch(e)))   
    b1 = Button(root, text='Save',
          command=(lambda e=ents: fetch(e)))
    b1.pack(side=LEFT, padx=5, pady=5)
    b2 = Button(root, text='Quit', command=cancel)
    b2.pack(side=LEFT, padx=5, pady=5)
    root.mainloop()
   
   
    outform = {}
    if (root.getvar('status') == 'ok'):
        for field in fields:
            outform[field] = root.getvar(field)
    
    try:
        root.destroy()    
    except:
        print('exit using the cross')
        
    return outform


def displayMessage(windowTitle,text):

    root = Tk()
    root.title(windowTitle)

    S = Scrollbar(root)
    T = Text(root, height=4, width=50)
    S.pack(side=RIGHT, fill=Y)
    T.pack(side=LEFT, fill=Y)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(END, text)
    
    b2 = Button(root, text='Quit', command=root.quit)
    b2.pack(side=LEFT, padx=5, pady=5)
    root.mainloop(  )
    
    try:
        root.destroy()
    except:
        print('exit using the cross')

def askQuestionYesNo(windowTitle,text):

    root = Tk()
    
    def yes():
        root.setvar(name='answer',value='yes')
        root.quit()
        
    def no():
        root.setvar(name='answer',value='no')
        root.quit()
        
        
    root.title(windowTitle)

    S = Scrollbar(root)
    T = Text(root, height=4, width=50)
    S.pack(side=RIGHT, fill=Y)
    T.pack(side=LEFT, fill=Y)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(END, text)
    
    b1 = Button(root, text='Yes', command=yes)
    b1.pack(side=BOTTOM, padx=0, pady=5)
    b2 = Button(root, text='No', command=no)
    b2.pack(side=BOTTOM, padx=0, pady=5)
    root.mainloop(  )
    answer=root.getvar('answer')

    try:
        root.destroy()
    except:
        print('exit using the cross')
        
    return answer      
