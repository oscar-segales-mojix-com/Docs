# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 14:12:24 2018

@author: jlinotte
"""

import pandas as pd
import os
import requests
import json

import pkg_resources

from libConfUtils import premiseNhubUtils as premiseNhubUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import deviceModelUtils as deviceModelUtils

requestTimeOut = 10
#
displayLogs =  True

#%%
def listEnv():
    file_name = pkg_resources.resource_filename('libConfUtils', 'env.xlsx') 
    df = pd.read_excel(file_name)

    listOfEnv = (df["NAME"]).tolist()
     
    
    return listOfEnv


def viewEnv():
    myList = listEnv()
    for env in myList:
        print(env)

#%%      
def chooseEnv(envName=None):
    
    if not envName:
          existingEnv = listEnv()
          envName = uiUtils.chooseWithMenu('Env',existingEnv)
 
    print('Env selected is ' + repr(envName))

    envDict  = {
                'urlDP':'urlDP',
                'urlDPConf':'urlDPConf',
                'token':'token',
                'headers':'headers',                
                'headers2':'headers2',
                }
    
    file_name = pkg_resources.resource_filename('libConfUtils', 'env.xlsx') 
    df = pd.read_excel(file_name)
    dataOftheEnv = df[df["NAME"]== envName]
    if (dataOftheEnv.size == 0) :
        print('premise ' +envName+ ' not found')
        #return 
    
            
    envDict  = {
                'urlDP':dataOftheEnv["urlDP"].values[0],
                'urlDPConf':dataOftheEnv["urlDP"].values[0] +'statemachine-api-configuration/rest/' ,
                'token':dataOftheEnv["tokenBasicAuth"].values[0],
                'headers':{'Authorization':'Basic ' + dataOftheEnv["tokenBasicAuth"].values[0]},                
                'headers2':{'Authorization':'Basic ' + dataOftheEnv["tokenBasicAuth"].values[0],'Content-Type':'application/json'}
    }
    
    return envDict  


#%% 
def choosePremise(myEnv=None, sort=True, filter=False):
    if not myEnv or not 'urlDP' in myEnv:
        existingEnv = listEnv()
        envName = uiUtils.chooseWithMenu('Env',existingEnv)
        if not envName:
            return ''
        myEnv = chooseEnv(envName)
        
    existingPremises = premiseNhubUtils.getAllPremisesCode(myEnv)
    if sort:
      existingPremises.sort()  
    if filter:
        existingPremises = [x for x in existingPremises if not x.startswith('AUTO')] 
    premiseCode = uiUtils.chooseWithMenu('Premise',existingPremises)
    myEnv = premiseNhubUtils.choosePremiseByCode(myEnv,premiseCode)
    return myEnv

#%% 
def chooseFloor(envDict=None, sort=True, filter=False):
    return _chooseChildLocation('Premise', choosePremise, 'Floor', envDict, sort, filter)   

#%% 
def chooseArea(envDict=None, sort=True, filter=False):
    return _chooseChildLocation('Floor', chooseFloor, 'Area', envDict, sort, filter)   
    
def chooseZone(envDict=None, sort=True, filter=False):
    return _chooseChildLocation('Area', chooseArea, 'Zone', envDict, sort, filter)   
    
def _chooseChildLocation(location, chooseMth, childLocation, envDict=None, sort=False, filter=False):
    if not envDict or not location+'Id' in envDict:
        envDict = chooseMth(envDict, sort, filter)
    
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
  
    if displayLogs:
        s = urlBase+'statemachine-api-configuration/rest/configuration/locations/' + envDict[location + 'Id'] + '/children' 
        print("GET " + s)

    response = requests.get(urlBase+'statemachine-api-configuration/rest/configuration/locations/' + envDict[location + 'Id'] + '/children', headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    floors = {x['name']: x['id'] for x in response.json()}
    found = list(floors.keys())
    found.sort()
    selected = uiUtils.chooseWithMenu(childLocation,found)
    envDict[childLocation+'Id'] = repr(floors.get(selected))
    envDict['LocationLevel'] = childLocation
    envDict['LocationId'] = envDict[childLocation+'Id']
   
    return envDict


#%% 
def chooseFixture(envDict=None, sort=True, filter=False, dialogTitle='Fixture'):
    if not envDict or not 'LocationId' in envDict:
            chooseMth = 'choose' + envDict['LocationLevel']
            envDict = chooseMth(envDict, sort, filter)
        
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
  
    response = requests.get(urlBase+'statemachine-api-configuration/rest/configuration/fixture/location/' + envDict['LocationId'], headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    floors = {x['name']: x['id'] for x in response.json()}
    found = list(floors.keys())
    found.sort()
    selected = uiUtils.chooseWithMenu(dialogTitle,found)
    envDict['FixtureId'] = floors.get(selected)
   
    return envDict


#%% 
def chooseDevice(envDict, sort=True, filter=False, deviceTypeSelector=None):
    modelsSelection = None

    if not envDict or not 'LocationId' in envDict:
        # Ask arbo to Zone if no location provided or already selected
        envDict = chooseZone(envDict, sort, filter)
        # remove fixture selection as parent might have changed
        if 'FixtureId' in envDict:
            del envDict['FixtureId']
        
    devices = deviceUtils.getDevicesOfLocation(envDict, deviceTypeSelector)

    # Filter device not linked to fixture id - not clean and efficient but it works
    if 'FixtureId' in envDict:
        devicesTemp = []
        for device in devices:
            toKeep = False
            povs = deviceUtils.getPovsLinkedToDevice(envDict, device['id'])
            for pov in povs:
                fixture = povUtils.getFixtureLinkedToPov(envDict, pov['id'])
                if fixture['id'] == envDict['FixtureId']:
                    toKeep = True
                    break
            if toKeep:
                devicesTemp.append(device)
        devices = devicesTemp
    
    if deviceTypeSelector:
        modelsSelection = deviceModelUtils.getModelsForDeviceType(envDict, deviceTypeSelector)
        modelsSelection = [x['id'] for x in modelsSelection]
        print('Models To Select: ' + repr(modelsSelection))
   
    listOfDevices = deviceUtils.getDevicesOfLocation(envDict, modelsSelection)
    listOfDevices = {x['name']: x for x in listOfDevices}
    found = list(listOfDevices.keys())
    print("Devices found: " + repr(found)) 
    if len(found) > 0:
        deviceName = uiUtils.chooseWithMenu('Device', found)
        print("Devices selected: " + deviceName) 
    else:
        raise LookupError('Do device found')

    envDict['device'] = listOfDevices.get(deviceName)

    return envDict

#%% 
def choosePov(envDict, sort=True, filter=False, deviceTypeSelector=None):
    if not envDict or not 'device' in envDict:
             envDict = chooseDevice(envDict, sort, filter, deviceTypeSelector)
             deviceId = envDict['device']['id']
      
    listOfPovs = deviceUtils.getPovsLinkedToDevice(envDict, deviceId)
    listOfPovs = {x['name']: x for x in listOfPovs}
    found = list(listOfPovs.keys())
    print("Povs found: " + repr(found)) 
    if len(found) > 0:
        povName = uiUtils.chooseWithMenu('Device', found)
        print("Povs selected: " + povName) 
    else:
        raise LookupError('device not found')

    envDict['pov'] = listOfPovs.get(povName)
   
    return envDict

#%% 
def chooseDeviceModel(envDict, deviceTypeSelector=None):
    deviceModelsSelection = None

    if deviceTypeSelector:
        deviceModelsSelection = deviceModelUtils.getModelsForDeviceType(envDict, deviceTypeSelector)
        deviceModelsSelection = {x['name']: x for x in deviceModelsSelection}
        print('Models To Select: ' + repr(deviceModelsSelection))
   
    found = list(deviceModelsSelection.keys())
    if len(found) == 0:
        raise LookupError('device model found')

    deviceModelFound = uiUtils.chooseWithMenu('Device Model', found)
   
    envDict['deviceModel'] = deviceModelsSelection.get(deviceModelFound)

    return envDict

#%% 
def choosePovModel(envDict, deviceModelSelector=None):
    deviceModelsSelection = None

    if deviceModelSelector:
        deviceModelsSelection = deviceModelUtils.getPovModelForDeviceModels(envDict, deviceModelSelector)
        deviceModelsSelection = {x['name']: x for x in deviceModelsSelection}
        print('Pov Model To Select: ' + repr(deviceModelsSelection))
   
    found = list(deviceModelsSelection.keys())
    if len(found) == 0:
        raise LookupError('Pov Model not found')

    deviceModelFound = uiUtils.chooseWithMenu('Pov Model', found)
   
    envDict['povModel'] = deviceModelsSelection.get(deviceModelFound)

    return envDict