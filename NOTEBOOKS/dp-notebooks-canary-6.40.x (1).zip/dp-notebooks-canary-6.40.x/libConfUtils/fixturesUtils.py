# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 17:03:35 2018

@author: jlinotte
"""

#%%
import requests
import json

requestTimeOut = 10
displayLogs  = False
#%%    
def getFixturesOfPremise(envDict):
    
    fixtureList_json =''
    if (envDict ==''):
        return
    
    #HUB = envDict.get('HUB')
    PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
      
    whatToDO = 'configuration/fixture/premise/' + PremiseCode
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Fixtures")
        fixtureList_json = response.json()
        print(json.dumps(fixtureList_json,indent=4))

    return fixtureList_json
 
#%%    
def getFixturesBySGLN(envDict,sgln):
    
    fixture_json = ''
    if sgln == '' :
        return fixture_json
    
    if (envDict ==''):
        return fixture_json
    
    HUB = envDict.get('HUB')
    PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    token = envDict.get('token')
    urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    
    whatToDO = 'configuration/fixture/' + sgln
    url=urlDPConf+whatToDO
    
    if displayLogs :
        print('GET ' + url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        fixture_json = response.json()
        print("Fixture" + json.dumps(fixture_json,indent=4))

        return fixture_json
    return fixture_json
    
#%%
def setFixtureByID(envDict,fixture_json,sgln):
    
    if fixture_json == '' :
        return
    if sgln == '':
        return
    if (envDict ==''):
        return
    HUB = envDict.get('HUB')
    PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    token = envDict.get('token')
    urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
        
    whatToDO = 'configuration/fixture/' + sgln
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2,json=fixture_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print("Fixture "+sgln+" Changed" + response.content.decode("utf-8"))
        return
    else : 
        print("Fixture "+sgln+" NOT Changed" + response.content.decode("utf-8"))
    
    return

#%% ADD MAIN Programm

