# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 19:08:29 2018

@author: jlinotte
"""


import requests
import json

requestTimeOut = 10
displayLogs  = True

#%% get all modles of the model type (paginated)
def getModelsForDeviceType(envDict, modelType):
    # TODO pagination not managed yet
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    url = urlBase + 'statemachine-api-configuration/rest/infra/device/types/' + modelType + '/models'
    if displayLogs:
        print ("GET "+url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()

def getDeviceTypes(envDict):
    # TODO pagination not managed yet
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    url = urlBase + 'statemachine-api-configuration/rest/infra/device/types'
    if displayLogs:
        print ("GET "+url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()

def getPovModelForDeviceModels(envDict, deviceModel):
    # TODO pagination not managed yet
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    url = urlBase + 'statemachine-api-configuration/rest/infra/device/models/' + deviceModel + "/pov/types"
    if displayLogs:
        print ("GET "+url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()


if __name__ == '__main__':
    envDict = {'urlDP': 'https://dpo-lab01.shopcx.io/', 'urlDPConf': 'https://dpo-lab01.shopcx.io/statemachine-api-configuration/rest/', 'token': 'dGVzdGVyOnRlc3Rpc2xpZmU', 'headers': {'Authorization': 'Basic dGVzdGVyOnRlc3Rpc2xpZmU'}}
    # print(getDeviceTypes(envDict)) 
    # print() 
    # result = getModelsForDeviceType(envDict, 'XPOINT')
    # print(result) 
    result = getPovModelForDeviceModels(envDict, 'IMPINJ__R220__1')
    print(result)
