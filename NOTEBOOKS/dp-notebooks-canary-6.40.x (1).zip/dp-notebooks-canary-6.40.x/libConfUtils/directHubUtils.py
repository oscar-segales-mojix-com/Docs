# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 16:25:15 2019

@author: jlinotte
"""

#%%
import requests
import json

requestTimeOut = 10
displayLogs  = True

portHub = '8080'
scheme = 'http://'
tokenBasicAuth = 'xxx'
headers = {'Authorization':'Basic ' + tokenBasicAuth}            
headersContentJson:{'Authorization':'Basic ' + tokenBasicAuth,'Content-Type':'application/json'} 
#%%    
def getConfigFiles_APL(hubIp):
    
    urlHUB = scheme + hubIp +':'+ portHub
                            
    whatToDO = '/apl-webservices/rest/configurationFile/getConfigurationLocation'
    url=urlHUB+whatToDO
    if displayLogs:
        print ("GET "+ url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Config Files")
        fileList_json = response.json()
        print(json.dumps(fileList_json,indent=4))

    return fileList_json
#%%    
def getConfigFiles_HAL(hubIp):
    
    urlHUB = scheme + hubIp +':'+ portHub
                            
    whatToDO = '/hal-webservices/rest/configurationFile/getConfigurationLocation'
    url=urlHUB+whatToDO
    if displayLogs:
        print ("GET "+ url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Config Files")
        fileList_json = response.json()
        print(json.dumps(fileList_json,indent=4))

    return fileList_json


#%%    
def downloadConfigFile_APL(hubIp,location):
    contentFile = ''
    
    urlHUB = scheme + hubIp +':'+ portHub
                            
    whatToDO = '/apl-webservices/rest/configurationFile/downloadConfiguration?location=' + location
    url=urlHUB+whatToDO
    if displayLogs:
        print ("GET "+ url)
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Config File:")
        contentFile  = response.content

    return contentFile
#%%    
#def downloadConfigFile_HAL(hubIp,location):
#    
#    urlHUB = scheme + hubIp +':'+ portHub
#                            
#    whatToDO = '/hal-webservices/rest/configurationFile/downloadConfiguration?location=' + location
#    url=urlHUB+whatToDO
#    if displayLogs:
#        print ("GET "+ url)
#    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
#    if response.ok:
#        print ("Config Files")
#        file_json = response.json()
#        print(json.dumps(file_json,indent=4))
#
#    return file_json


#%%    
def uploadConfigFile_APL(hubIp,targetFileLocation,fileName):

    res = {
       'status' : False,
       'message' : ''
       }
    
    urlHUB = scheme + hubIp +':'+ portHub
                            
    whatToDO = '/apl-webservices/rest/configurationFile/uploadConfiguration'
    url=urlHUB+whatToDO
    
    try :
        multipart_form_data = {
        'path': targetFileLocation,
        'file': (fileName, open(fileName, 'rb'),'application/octet-stream')
        }
    except:
        message = 'Error, can not open file'
        res['message']= message
        print(message)
        return res
        
    if displayLogs:
        print ("POST "+ url)
        #print("multipart_form_data" + json.dumps(multipart_form_data,indent=4))

    response = requests.post(url, headers=headers, verify=True, timeout=requestTimeOut,files=multipart_form_data)
    if response.ok:
        print ("Config Files")
        print(response.content.decode("utf-8"))
        message = 'Success '+ 'file ' + fileName + ' in the HUB at '+targetFileLocation
        res['status'] = True
        res['message'] = message
        print(message)

    else:
        print(response.content.decode("utf-8"))
        message = 'Success '+ 'file ' + fileName + ' in the HUB at '+targetFileLocation
        res['message'] = message
        print(message)
        
    return res