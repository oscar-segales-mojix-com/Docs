# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 22:58:27 2018

@author: jlinotte
"""


#%%
import requests
import json


requestTimeOut = 10
displayLogs = False

#%% add help here
def getHelp():
    print('POV Utils Help')
    print(' getPovOfPremise(envDict)')
    print(' getPovById(envDict,povId)')
    print(' deletePovById(envDict,povId)')


#%%    
def getPovOfPremise(envDict):
    
    allPov_json =''
    if (envDict ==''):
        return
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    whatToDO = 'locations/'+ PremiseId +'/infra/povs'
    url=urlDPConf+whatToDO
    
    if displayLogs:
        print('GET '+url)
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Povs")
        allPov_json = response.json() #réponse sous format JSON
        print(json.dumps(allPov_json,indent=4))

    # TODO: create a dict
    return allPov_json

#%%
def getPovById(envDict,povId):

    if envDict =='':
        return

    if povId == '':
        return
    
    povExist = True
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    pov_json = ""
    povType_json = ""
    povDevice_json = ""
    povFixture_json = ""
    povSettings_json = ""

    whatToDO = 'infra/povs/'+ povId
    url=urlDPConf+whatToDO
    
    if displayLogs :
        print('GET ' + url)

    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        pov_json = response.json() #réponse sous format JSON
        print ("ID : " + pov_json.get('id'))
        if 'mac' in pov_json :
            print ("MAC: " + pov_json.get('mac'))
        if 'address' in pov_json :
            print ("ADD: " + pov_json.get('address'))
            
        print(json.dumps(pov_json,indent=4))
    
    else :
        print("fail" + response.content.decode("utf-8"))
        povExist = False
    
    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/type'
      url=urlDPConf+whatToDO
      if displayLogs:
          print('GET '+url)
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povType_json = response.json() #réponse sous format JSON
          print(povId + " Type:")
          print(json.dumps(povType_json,indent=4))
      else :
        print("fail Type" + response.content.decode("utf-8"))
    
    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/device'
      url=urlDPConf+whatToDO
      if displayLogs:
          print('GET '+url)
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povDevice_json = response.json() #réponse sous format JSON
          print(povId + " Device:")
          print(json.dumps(povDevice_json,indent=4))
      else :
        print("fail Device" + response.content.decode("utf-8"))    

    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/fixture'
      url=urlDPConf+whatToDO
      if displayLogs:
          print('GET '+url)
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povFixture_json = response.json() #réponse sous format JSON
          print(povId + " fixture:")
          print(json.dumps(povFixture_json,indent=4))
    
      else :
        print("fail fixture" + response.content.decode("utf-8"))

    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/settings'
      url=urlDPConf+whatToDO
      if displayLogs:
          print('GET '+url)
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povSettings_json = response.json() #réponse sous format JSON
          print(povId + " pov settings:" )
          print(json.dumps(povSettings_json,indent=4))
      else :
        print("fail pov settings" + response.content.decode("utf-8"))
    
    #output
    povDict  = {'pov':pov_json,
               'povType':povType_json,
               'povDevice':povDevice_json,
               'povFixture':povFixture_json,
               'povSettings':povSettings_json}

    return povDict

#%% delete pov by Id
def deletePovById(envDict,povId):

    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')


    whatToDO = 'infra/povs/'+ povId + '/device'            
    url=urlDPConf+whatToDO
    if displayLogs:
        print('DELETE '+url)
        
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("ID : " + povId + " device link deleted")
    else :
        print ("fail delete device link " + response.content.decode("utf-8"))
    
    whatToDO = 'infra/povs/'+ povId + '/fixture'            
    url=urlDPConf+whatToDO
    if displayLogs:
        print('DELETE '+url)
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("ID : " + povId + " fixture link deleted")
    else :
        print ("fail delete fixture link " + response.content.decode("utf-8"))
    
    whatToDO = 'infra/povs/'+ povId
    url=urlDPConf+whatToDO
    if displayLogs:
        print('DELETE '+url)
    response = requests.delete(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("ID : " + povId + " deleted")
    else :
        print ("fail delete " + response.content.decode("utf-8"))

    return True

#%%
def getPovTypes(envDict):

    if envDict =='':
        return


    allPovType_json = ''
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    
    whatToDO = 'infra/pov/types'
    url=urlDPConf+whatToDO
    if displayLogs:
        print('GET '+url)
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Pov Type")
        allPovType_json = response.json() #réponse sous format JSON
        print(json.dumps(allPovType_json,indent=4))
    else :
        print ("fail " + response.content.decode("utf-8"))
        
    # TODO: create a dict
    return allPovType_json

def createOrUpdatePovTypes(envDict,brand,model,version):
    if envDict == '' :
        return
    id = brand + "_" +model+"_"+version
    povType_json = {
            "id":id,
            "name":model,
            "brand":brand,
            "version":version
    }
    
    urlDPConf = envDict.get('urlDPConf')
    headers2 = envDict.get('headers2')
    
    whatToDO = 'infra/pov/types/'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = povType_json  ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(" povType:" + response.content.decode("utf-8"))
    else :
        print("fail to get povType " + response.content.decode("utf-8"))


#2.4.10. Add a compatible pov type to this model.
#PUT /infra/device/models/{id}/pov/types/{idType}
    

#%% delete pov by Id
def transformPovForPN(envDict,povId):
    if envDict =='':
        return False

    if povId == '':
        return False

    povTypeId = 'CANT__00'
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')


    whatToDO = 'infra/povs/'+ povId + '/type/' +povTypeId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:   
        print(povId + " Type updated")
    else :
        print("fail update Type" + response.content.decode("utf-8"))
    
#%% create an CLuster POV (for a PN)
def createPovForPN(envDict,povId):

    return 
    # TODO not finished
    if envDict =='':
        return

    if povId == '':
        return
    
    povExist = True
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    pov_json = ""
    povType_json = ""
    povDevice_json = ""
    povFixture_json = ""
    povSettings_json = ""

# POV
    whatToDO = 'infra/povs/'+ povId
    url=urlDPConf+whatToDO
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        pov_json = response.json() #réponse sous format JSON
        print ("ID : " + pov_json.get('id'))
        if 'mac' in pov_json :
            print ("MAC: " + pov_json.get('mac'))
        if 'address' in pov_json :
            print ("ADD: " + pov_json.get('address'))
            
        print(json.dumps(pov_json,indent=4))
    
    else :
        print("fail" + response.content.decode("utf-8"))
        povExist = False
# POV Type    
    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/type'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povType_json = response.json() #réponse sous format JSON
          print(povId + " Type:")
          print(json.dumps(povType_json,indent=4))
      else :
        print("fail Type" + response.content.decode("utf-8"))

# link to device (if exist)    
    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/device'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povDevice_json = response.json() #réponse sous format JSON
          print(povId + " Device:")
          print(json.dumps(povDevice_json,indent=4))
      else :
        print("fail Device" + response.content.decode("utf-8"))    

# link to fixture (if exist) 

    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/fixture'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povFixture_json = response.json() #réponse sous format JSON
          print(povId + " fixture:")
          print(json.dumps(povFixture_json,indent=4))
    
      else :
        print("fail fixture" + response.content.decode("utf-8"))

# settings

    if povExist:
      whatToDO = 'infra/povs/'+ povId + '/settings'
      url=urlDPConf+whatToDO
      response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
      if response.ok:   
          povSettings_json = response.json() #réponse sous format JSON
          print(povId + " pov settings:" )
          print(json.dumps(povSettings_json,indent=4))
      else :
        print("fail pov settings" + response.content.decode("utf-8"))
        
#%% create a POS  POV (for a KEONN)
def createPovForPOS(envDict,povId,PovName,fixture,deviceId):
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    # create the POV
    pov_json = {
      'id': povId,
      "name": PovName,
      "address": "1",
      "isEnabled" : True
    }
    
    whatToDO = 'infra/povs'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = pov_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov :  updated")
    else :
        print ("fail create pov " + response.content.decode("utf-8")) 
     
    # Set Model        
    whatToDO = 'infra/povs/'+povId +'/type/'+'KEONN__ADPY__1'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create povType :  updated")
    else :
        print ("fail create povType " + response.content.decode("utf-8"))
    
    
    # TODO: check that the settings exist
    
    settingsName = 'KEONN_POV' # KEONN_POV /POS_POV_DEFAULT
    # Set Mode
    whatToDO = 'infra/povs/'+povId +'/mode/POS_RETURN/settings/'+settingsName
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov POS_RETURN :  updated")
    else :
        print ("fail create pov POS_RETURN" + response.content.decode("utf-8"))
    
    whatToDO = 'infra/povs/'+povId +'/mode/POS_PAYMENT/settings/'+settingsName
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov POS_PAYMENT :  updated")
    else :
        print ("fail create pov POS_PAYMENT" + response.content.decode("utf-8"))
        
    whatToDO = 'infra/povs/'+povId +'/mode/POS_READ_ONLY/settings/'+settingsName
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov POS_READ_ONLY :  updated")
    else :
        print ("fail create pov POS_READ_ONLY" + response.content.decode("utf-8"))
        
 

    # Link to fixture 
    if fixture != '':
        whatToDO = 'infra/povs/'+povId +'/fixture/'+fixture
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pov2fixture :  updated")
        else :
            print ("fail create pov2fixture " + response.content.decode("utf-8"))

    # Link to device
    if deviceId != '':
        whatToDO = 'infra/devices/'+deviceId +'/povs/' + povId
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pos link to pov :  updated")
        else :
            print ("fail create pos link to pov" + response.content.decode("utf-8"))
        
#%% create a XPT  POV (for a Impinj or SF)
def createPovForXPT_defaultProfil(envDict,povId,PovName,fixture,deviceId,modelId,antId):
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    # create the POV
    pov_json = {
      'id': povId,
      "name": PovName,
      "address": antId,
      "isEnabled" : True
    }
    
    whatToDO = 'infra/povs'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = pov_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov :  updated")
    else :
        print ("fail create pov " + response.content.decode("utf-8")) 
     
    # Set Model        
    whatToDO = 'infra/povs/'+povId +'/type/'+ modelId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create povType :  updated")
    else :
        print ("fail create povType " + response.content.decode("utf-8"))
    
    

    #
    whatToDO = 'infra/povs/'+povId+'/mode/XPOINT/settings/'+ 'XPOINT_POV_DEFAULT'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers , verify=True, timeout=requestTimeOut)
    if response.ok:    
        print("pov ant settings OK") 
    else :
        print("fail" + response.content.decode("utf-8")) 
           
    # Link to fixture 
    if fixture != '':
        whatToDO = 'infra/povs/'+povId +'/fixture/'+fixture
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pov2fixture :  updated")
        else :
            print ("fail create pov2fixture " + response.content.decode("utf-8"))

    # Link to device
    if deviceId != '':
        whatToDO = 'infra/devices/'+deviceId +'/povs/' + povId
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pos link to pov :  updated")
        else :
            print ("fail create device link to pov" + response.content.decode("utf-8"))
        

#%% Create Pov
def createPov(envDict,povAnts,povName,povId=None, povModel='KEONN__SP11__1'):
    povId = _createPov(envDict, povAnts, povName, povId, None)
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/povs/' + povId + '/type/' + povModel, headers=headers, verify=True, timeout=requestTimeOut)
    print('Pov Model: ', response.status_code)
    if response.status_code != 204:
        print('Pov Model: ', povModel)
        raise Exception(response.content.decode("utf-8"))

    return povId


def linkPovToDevice(envDict, povId, deviceId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
   
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/povs/' + povId + '/device/' + deviceId , headers=headers, verify=True, timeout=requestTimeOut)
    print('Pov Model: ', response.status_code)
    if response.status_code != 204:
        raise Exception(response.content.decode("utf-8"))

    print('Pov ' + povId + ' linked to device ' + deviceId)

def getDeviceLinkedToPov(envDict, povId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
   
    response = requests.get(urlBase + 'statemachine-api-configuration/rest/infra/povs/' + povId + '/device' , headers=headers, verify=True, timeout=requestTimeOut)
    print('Pov Model: ', response.status_code)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()

def linkPovToFixture(envDict, povId, fixtureId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
   
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/povs/' + povId + '/fixture/' + fixtureId , headers=headers, verify=True, timeout=requestTimeOut)
    print('Pov Model: ', response.status_code)
    if response.status_code != 204:
        raise Exception(response.content.decode("utf-8"))

    print('Pov ' + povId + ' linked to fixture ' + fixtureId)

def getFixtureLinkedToPov(envDict, povId):
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')
   
    response = requests.get(urlBase + 'statemachine-api-configuration/rest/infra/povs/' + povId + '/device' , headers=headers, verify=True, timeout=requestTimeOut)
    print('Pov Model: ', response.status_code)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))

    return response.json()

    
#%% Create Device
def _createPov(envDict,povAnts,povName,povId=None, povMac=None):

    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers')

    payload = {
      'name': povName,
      'address': povAnts,
      'isEnabled': True
    }

    if not povAnts:
        raise Exception('Missing Pov Antennas')
    if not povName:
        raise Exception('Missing Pov Name')

    if povId:
        payload['id'] = povId
    if povMac:
        payload['mac'] = povMac
   
    response = requests.put(urlBase + 'statemachine-api-configuration/rest/infra/povs', headers=headers, json=payload, verify=True, timeout=requestTimeOut)
    if response.status_code != 200:
        raise Exception(response.content.decode("utf-8"))
    
    povId = response.json()['id']
    print('POV id: ', povId)
   
    return povId


if __name__ == '__main__':
    envDict = {'urlDP': 'https://dpo-lab01.shopcx.io/', 'urlDPConf': 'https://dpo-lab01.shopcx.io/statemachine-api-configuration/rest/', 'token': 'dGVzdGVyOnRlc3Rpc2xpZmU', 'headers': {'Authorization': 'Basic dGVzdGVyOnRlc3Rpc2xpZmU'}}
    print() 
    povId = createXptPov(envDict, '1', 'XPoint Test Device')
    print(povId)
    # deleteDeviceById(envDict, deviceId)

#%% create a XPT  POV (for a Impinj or SF)
def createPovForXPT(envDict,povId,PovName,fixture,deviceId,modelId,antId,profilID):
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    # create the POV
    pov_json = {
      'id': povId,
      "name": PovName,
      "address": antId,
      "isEnabled" : True
    }
    
    whatToDO = 'infra/povs'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = pov_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov :  updated")
    else :
        print ("fail create pov " + response.content.decode("utf-8")) 
     
    # Set Model        
    whatToDO = 'infra/povs/'+povId +'/type/'+ modelId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create povType :  updated")
    else :
        print ("fail create povType " + response.content.decode("utf-8"))
    
    

    # check That the profil exists
    whatToDO = 'infra/povs/'+povId+'/mode/XPOINT/settings/'+ profilID
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers , verify=True, timeout=requestTimeOut)
    if response.ok:    
        print("pov ant settings OK") 
    else :
        print("fail" + response.content.decode("utf-8")) 
           
    # Link to fixture 
    if fixture != '':
        whatToDO = 'infra/povs/'+povId +'/fixture/'+fixture
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pov2fixture :  updated")
        else :
            print ("fail create pov2fixture " + response.content.decode("utf-8"))

    # Link to device
    if deviceId != '':
        whatToDO = 'infra/devices/'+deviceId +'/povs/' + povId
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pos link to pov :  updated")
        else :
            print ("fail create device link to pov" + response.content.decode("utf-8"))
#%% create a XPT  POV (for a Impinj or SF)
def createPovForL40(envDict,povId,PovName,fixture,deviceId):
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')
    
    # create the POV
    pov_json = {
      'id': povId,
      "name": PovName,
      "address": 0,
      "isEnabled" : True
    }
    
    whatToDO = 'infra/povs'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers2 ,json = pov_json, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create pov :  updated")
    else :
        print ("fail create pov " + response.content.decode("utf-8")) 
     
    # Set Model
    modelId = 'INVENGO__LSA4__1'     
    whatToDO = 'infra/povs/'+povId +'/type/'+ modelId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("create povType :  updated")
    else :
        print ("fail create povType " + response.content.decode("utf-8"))
    
    

    #
    whatToDO = 'infra/povs/'+povId+'/mode/XPOINT/settings/'+ 'HF_POV_DEFAULT'
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers , verify=True, timeout=requestTimeOut)
    if response.ok:    
        print("pov ant settings OK") 
    else :
        print("fail" + response.content.decode("utf-8")) 
           
    # Link to fixture 
    if fixture != '':
        whatToDO = 'infra/povs/'+povId +'/fixture/'+fixture
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pov2fixture :  updated")
        else :
            print ("fail create pov2fixture " + response.content.decode("utf-8"))

    # Link to device
    if deviceId != '':
        whatToDO = 'infra/devices/'+deviceId +'/povs/' + povId
        url=urlDPConf+whatToDO
        response = requests.put(url, headers=headers, verify=True, timeout=requestTimeOut)
        if response.ok:
            print ("create pos link to pov :  updated")
        else :
            print ("fail create device link to pov" + response.content.decode("utf-8"))
            
            
#%% 
def deleteLinkWithFixture(envDict,povId,fixture):
    #DELETE /fixtures/{id}/povs/{idPov}
    
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')

    
    whatToDO = 'fixtures/'+fixture+'/povs/'+povId
    url=urlDPConf+whatToDO
    response = requests.delete(url, headers=headers , verify=True, timeout=requestTimeOut)
    print ('delete ' + url)
    if response.ok:
        print ("delete pov link:  updated")
    else :
        print ("fail delete pov link" + response.content.decode("utf-8")) 


#%%
def createLinkWithFixture(envDict,povId,fixture):
    #DELETE /fixtures/{id}/povs/{idPov}
    
    if envDict =='':
        return False

    if povId == '':
        return False

    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    #PremiseId = envDict.get('PremiseId')
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    headers2  = envDict.get('headers2')

    
    whatToDO = 'fixtures/'+fixture+'/povs/'+povId
    url=urlDPConf+whatToDO
    response = requests.put(url, headers=headers , verify=True, timeout=requestTimeOut)
    print ('put ' + url)
    if response.ok:
        print ("create pov link :  updated")
    else :
        print ("fail create pov link" + response.content.decode("utf-8")) 
