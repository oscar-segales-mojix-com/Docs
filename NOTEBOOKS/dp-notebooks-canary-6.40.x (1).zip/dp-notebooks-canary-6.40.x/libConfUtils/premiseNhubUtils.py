# -*- coding: utf-8 -*-
"""
Created on Tue Aug  7 16:56:51 2018

@author: jlinotte
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 22:58:27 2018

@author: jlinotte
"""


#%%
import requests
import json


requestTimeOut = 10
# Set to false in git
displayLogs = False
#%%
def getAllPremises(envDict):

    allPremise_json =''
    if (envDict ==''):
        return
    

    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    whatToDO = 'configuration/locations?level=premise'
    url=urlDPConf+whatToDO
    
    if displayLogs :
        print('GET ' +url)
        
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        #print ("Premises")
        allPremise_json = response.json() #réponse sous format JSON
        #print(json.dumps(allPremise_json,indent=4))

    # TODO: create a dict
    return allPremise_json

 

def getAllPremisesCode(envDict):

    allPremise_json =''
    if (envDict ==''):
        return
    listOfcodes = []
  
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    whatToDO = 'configuration/locations?level=premise'
    url=urlDPConf+whatToDO
    if displayLogs :
        print('GET ' +url)
        
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("Premises")
        allPremise_json = response.json() #réponse sous format JSON
        print(json.dumps(allPremise_json,indent=4))

        for premise in allPremise_json:
            listOfcodes.append(premise.get('code'))
            
    return listOfcodes


def viewPremise(envDict):
    myList = getAllPremises(envDict)
    for premise in myList:
        message = "code:" + premise.get('code') + " name:"+premise.get('name')+ " id:"+str(premise.get('id'))
        print(message)

        
def choosePremiseByCode(envDict,premiseCode):
    
    premise_json =''
    if (envDict ==''):
        return
    
    premiseDict  = {'HUB':'HUB',
                'PremiseId':'0',
                'PremiseCode':'PremiseCode',
                'urlDP':'urlDP',
                'urlDPConf':'urlDPConf',
                'token':'token',
                'headers':'headers',                
                'headers2':'headers2',
                }  
    #token = envDict.get('token')
    #urlDP = envDict.get('urlDP')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    whatToDO = 'configuration/locations/code/premise/' + premiseCode
    url=urlDPConf+whatToDO
    
    if displayLogs :
        print('GET ' +url)
    
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        #print ("Premise")
        premise_json = response.json() #réponse sous format JSON
        #print(json.dumps(premise_json,indent=4))


    #search the HUB
    allHUBs = getAllHUBS(envDict)
    hubId = ''
    for theHub in allHUBs:
       if (theHub.get('locationLevel') == 'premise' and theHub.get('locationCode') == premiseCode):
           hubId = theHub.get('id')  
           break
        
    if hubId == "":
        print("WARN no hub found")
        
    premiseDict  = {'HUB':hubId,
                'PremiseId':str(premise_json.get('id')),
                'PremiseCode':premiseCode,
                'urlDP':envDict.get('urlDP'),
                'urlDPConf':envDict.get('urlDPConf') ,
                'token':envDict.get('token') ,
                'headers':envDict.get('headers'),                
                'headers2':envDict.get('headers2')
    }
    
    return premiseDict
    
    
    
    
#%%    
def getAllHUBS(envDict):
    
    allHUB_json =''
    if (envDict ==''):
        return
    

    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    #headers2  = envDict.get('headers2')
    
    whatToDO = 'configuration/hub'
    url=urlDPConf+whatToDO
    
    if displayLogs :
        print('GET ' +url)
    
    response = requests.get(url, headers=headers ,verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUBS")
        allHUB_json = response.json() #réponse sous format JSON
        print(json.dumps(allHUB_json,indent=4))

    # TODO: create a dict
    return allHUB_json



# 2.1.61. Retrieve all the settings
# GET /configuration/settings
    
def HUB_settings_lastupdate(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'infra/hub/'+HUB+'/settings/lastupdate'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB settings_lastupdate")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no settings_lastupdate" + response.content.decode("utf-8"))   
        
    return HUB_json


def HUB_settings(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'infra/hub/'+HUB+'/settings'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB settings")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no settings" + response.content.decode("utf-8"))   
        
    return HUB_json


def HUB_supervision(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    urlBase = envDict.get('urlDP')
    headers = envDict.get('headers2') # with content.
    HUB = envDict.get('HUB')

    payload = {
      'hubId': HUB,
      'message': ''
    }

    # url = urlBase + 'statemachine-api-configuration/rest/supervision/hub'
    url = urlBase + 'statemachine-api-supervision/rest/supervision/hub'
    if displayLogs:
        print("POST " + url)  
        print(json.dumps(payload,indent=4))
   
    response = requests.post(url, headers=headers, json=payload, verify=True, timeout=requestTimeOut)
                            
    if response.ok:
        print ("HUB supervision")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no supervision" + response.content.decode("utf-8"))   
        
    return HUB_json



def HUB_rules(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'configuration/rules/hub/'+HUB+'/fixtures'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB rules")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no rules" + response.content.decode("utf-8"))   
        
    return HUB_json


def HUB_readcycles(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'configuration/hub/'+HUB+'/readcycles'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB readcycles")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no readcycles" + response.content.decode("utf-8"))   
        
    return HUB_json


#GET statemachine-api-configuration/rest/configuration/rfidprofile/{rfidProfileIds}
def HUB_Allrfidprofiles(envDict):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'configuration/rfidprofile'
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB readcycles")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no readcycles" + response.content.decode("utf-8"))   
        
    return HUB_json


def HUB_rfidprofile(envDict,rfidProfileIds):
    HUB_json = ''
    if (envDict ==''):
        return HUB_json
    
    #HUB = envDict.get('HUB')
    #PremiseCode = envDict.get('PremiseCode')
    urlDPConf = envDict.get('urlDPConf')
    headers = envDict.get('headers')
    HUB = envDict.get('HUB')
    print ('HUB: ' + repr(HUB))
    
    whatToDO = 'configuration/rfidprofile'+rfidProfileIds
    url=urlDPConf+whatToDO
    if displayLogs:
        print("GET " + url)
        
    response = requests.get(url, headers=headers, verify=True, timeout=requestTimeOut)
    if response.ok:
        print ("HUB readcycles")
        HUB_json = response.json()
        print(json.dumps(HUB_json,indent=4))
    else :
        print("no readcycles" + response.content.decode("utf-8"))   
        
    return HUB_json

#POST /printing-api/rest/printing/statuses


#GET statemachine-api-configuration/rest/configuration/hub/{hubId}
#GET statemachine-api-configuration/rest/configuration/hs/{hsIds}
#GET statemachine-api-configuration/rest/configuration/pn/{pnIds}

