# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 20:10:49 2018

@author: jlinotte
"""

from libConfUtils import uiUtils as uiUtils

import os
import qrcode
import pandas as pd

#%% Choose file
#  file definition:
# Mandatory for PowerNode creation: one column should be named "QRCode"
# To use this file with the other utils, it should be formmatted like:
# |Name|otherInfo|QRCode|OtherInfo
# first row is always the name (row name does not affect)
# QRCode" row position can be changed 

# QRCODE Format:
# Fixture:
# FIXT={"sgln":"3663328.00004.1014"}
# PowerNode
# PNOD={"a":"00:07:80:B1:F3:0A","r":"00"}
# Antenna cluster
# CANT={"a":"3:0:000000:123ABC29","r":"00"}

initialdirectory = ""
file_name = uiUtils.getOneFile(initialdirectory,"Select Excel file",(("xlsx files","*.xlsx"),("all files","*.*")))
#%% Load File
df = pd.read_excel(file_name)
baseName = os.path.dirname(file_name)

for index, row in df.iterrows():
    name = row[0]
    qrcodeString = row["QRCode"]
    # Create qr code instance
    qr = qrcode.QRCode(
    version = 1,
    error_correction = qrcode.constants.ERROR_CORRECT_H,
    box_size = 10,
    border = 4,
    )       
    # Add data
    qr.add_data(qrcodeString)
    qr.make(fit=True)      
    # Create an image from the QR Code instance
    img = qr.make_image()      
    # Save it somewhere, change the extension as needed:
    img.save(os.path.join(baseName,name+".jpg"))         
