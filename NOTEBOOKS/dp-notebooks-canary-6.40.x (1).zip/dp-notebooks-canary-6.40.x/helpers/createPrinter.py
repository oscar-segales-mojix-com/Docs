# -*- coding: utf-8 -*-
"""
Created on Fri Nov 30 15:39:15 2018

@author: jlinotte
"""


#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils


#%%
myEnv = chooseEnv.choosePremise()
print("Organization:" + myEnv.get('urlDP') + " Premise code"+  myEnv.get('PremiseCode'))
#%%
myForm = uiUtils.inputWithForm('printer definition',['IP','ID(integer)','NAME','MAC','FIXTURE'])

printerIp = myForm.get('IP')
printerId = myForm.get('ID(integer)') # NUMBER
printerName = myForm.get('NAME')
printerMac = myForm.get('MAC') # can be fake
printerFixture = myForm.get('FIXTURE') 
#%%
deviceUtils.createPrinter(myEnv,printerIp,printerId,printerName,printerMac,printerFixture)

#%% check
deviceUtils.getPrintersOfPremise(myEnv)
