# -*- coding: utf-8 -*-
"""
Created on Wed Dec 26 15:32:22 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils


#%%

myEnv = chooseEnv.choosePremise()

#%% choose device
listOfPov = povUtils.getPovOfPremise(myEnv)

listOfNames = []
for pov in listOfPov:
    nameOfPov = pov.get('name')
    if not nameOfPov:
        nameOfPov = "NoName"
    idOfpov = pov.get('id')
    str2Display =  idOfpov + ":" +nameOfPov
    listOfNames.append(str2Display)
    
povC = uiUtils.chooseWithMenu('PointOfViews',listOfNames)
tmp = povC.split(':')
povId = tmp[0]

#%%
povUtils.deletePovById(myEnv,povId)