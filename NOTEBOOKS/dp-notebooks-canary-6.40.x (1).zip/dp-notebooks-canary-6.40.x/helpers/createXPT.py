# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 10:08:16 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from tkinter import Tk
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import askopenfilenames

import os
#%%
import compileall
import importlib

compileall.compile_dir('libConfUtils')

importlib.reload(chooseEnv)
importlib.reload(deviceUtils)
importlib.reload(povUtils)

import requests
import json
#%%
myEnv = chooseEnv.chooseEnv('QAShowroom')

xpName = 'QA_Impinj1'
xpIp = '10.100.1.27'
deviceID = 'QA_Impinj1'
xpModel = 'IMPINJ__R420__1'
antModel = 'MOJIX_STAR_ANT_1'



#%% 
#povUtils.getPovTypes(myEnv)

tmp = deviceUtils.createXPT(myEnv,xpIp,deviceID,xpName,xpModel)
#%%
pov1_antid = '1'
pov1_fixture = '3663328.01000.2003'

pov1_id = deviceID + '_' +  pov1_antid
pov1_name = xpName + '_' + pov1_antid
povUtils.createPovForXPT_defaultProfil(myEnv,pov1_id,pov1_name,pov1_fixture,deviceID,antModel,pov1_antid)

pov2_antid = '2'
pov2_fixture = '3663328.01000.2014'
pov2_id = deviceID + '_' +  pov2_antid
pov2_name = xpName + '_' + pov2_antid
povUtils.createPovForXPT_defaultProfil(myEnv,pov2_id,pov2_name,pov2_fixture,deviceID,antModel,pov2_antid)


deviceUtils.linkDeviceToPov(myEnv,pov1_id,deviceID)

#%% debug
deviceUtils.getAllDevices(myEnv)
deviceUtils.getDevicesOfPremise(myEnv)
deviceUtils.getDeviceById(myEnv,deviceID)

povUtils.getPovById(myEnv,povId)






#%%
deviceExist = False

newXP_json = {
  'address': xpIp,
  'isEnabled': True,
  'name': xpName
}

whatToDO = 'infra/devices/'+ xpID
url=urlDPConf+whatToDO
response = requests.put(url, headers=headers2 ,json = newXP_json , verify=True)
if response.ok:
    xpCreate_json = response.json() #réponse sous format JSON
    xpID = xpCreate_json.get('id')
    deviceExist = True

else :
    print("fail" + response.content.decode("utf-8"))    


whatToDO = 'infra/devices/'+ xpID
url=urlDPConf+whatToDO
response = requests.get(url, headers=headers ,verify=True)
if response.ok:
    device_json = response.json() #réponse sous format JSON
    print ("ID : " + device_json.get('id'))
    xpID = device_json.get('id')
    if 'mac' in device_json :
        print ("MAC: " + device_json.get('mac'))
    if 'address' in device_json :
        print ("ADD: " + device_json.get('address'))
else :
    print("fail" + response.content.decode("utf-8"))
    deviceExist = False

# model
whatToDO = 'infra/devices/'+ xpID +'/model/' + xpModel
url=urlDPConf+whatToDO
response = requests.put(url, headers=headers ,verify=True)
if response.ok:   
    print(xpID + " change model:" + response.content.decode("utf-8"))
else :
    print("fail change model " + response.content.decode("utf-8"))
    
# startUp Mode
xpStartUpMode = 'XPOINT'    
whatToDO = 'infra/devices/'+ xpID + '/startupmode/' + xpStartUpMode
url=urlDPConf+whatToDO
response = requests.put(url, headers=headers ,verify=True)
if response.ok:   
    print(xpID + " put startupmode :" + response.content.decode("utf-8"))
else :
  print("fail put startupmode" + response.content.decode("utf-8"))
  
  
  
whatToDO = 'infra/devices/'+xpID +'/mode/XPOINT/settings/XPOINT_DEFAULT'
url=urlDPConf+whatToDO
response = requests.put(url, headers=headers, verify=True)
if response.ok:
    print ("xpoint XPOINT/settings/XPOINT_DEFAULT :  updated")
else :
    print ("fail create pos XPOINT/settings/XPOINT_DEFAULT" + response.content.decode("utf-8"))
    
    
    