# -*- coding: utf-8 -*-
"""
Created on Fri Dec 21 10:58:31 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils


#%%
myEnv = chooseEnv.choosePremise()

#%% choose device
listOfDevices = deviceUtils.getDevicesOfPremise(myEnv)

listOfNames = []
for device in listOfDevices:
    nameOfDevice = device.get('name')
    if not nameOfDevice:
        nameOfDevice = "NoName"
    idOfDevice = device.get('id')
    str2Display =  idOfDevice + ":" +nameOfDevice
    listOfNames.append(str2Display)
    
deviceC = uiUtils.chooseWithMenu('Devices',listOfNames)
tmp = deviceC.split(':')
deviceId = tmp[0]

#%%
deviceDefinition = deviceUtils.getDeviceById(myEnv,deviceId)
#%%
listOfPov = deviceDefinition.get('devicePov')
povDetails = {}
for pov in listOfPov:
    povid = pov.get('id')
    povDetails[povid] = povUtils.getPovById(myEnv,povid)
#%%
text = "Premise: " + str(myEnv.get('PremiseCode'))
device = deviceDefinition.get('device')
text  = text +'\n' + 'device ID: ' +  deviceId
text  = text +'\n' + 'device IP: ' +  device.get('address')
text  = text +'\n' + 'device NAME: ' +  device.get('name')

dType = deviceDefinition.get('deviceType')
typeText = "Brand " +dType.get('brand')+ " Model "+dType.get('name')+" Version " +dType.get('version')
text  = text +'\n' + 'device type : ' +  typeText

text  = text +'\n' + 'device mode : ' 
deviceModes = deviceDefinition.get('deviceMode')
for mode in deviceModes:
    text  = text +'\n' + '    '+ str(mode.get('name'))


deviceStarUpMode = deviceDefinition.get('deviceStarUpMode') 
text  = text +'\n' + 'startUp mode : ' + deviceStarUpMode.get('name')

text  = text +'\n' + 'POV : ' 

for povid in povDetails:
    povDetail = povDetails[povid]
    text  = text +'\n' + '    ID: '+ str(povid)
    povGeneralDefinition = povDetail.get('pov')
    text  = text +'\n' + '        name: '+ str(povGeneralDefinition.get('name'))
    text  = text +'\n' + '        address: '+ str(povGeneralDefinition.get('address'))
    text  = text +'\n' + '        isEnable: '+ str(povGeneralDefinition.get('isEnabled'))

    povType = povDetail.get('povType')
    typeText = "Brand " +povType.get('brand')+ " Model "+povType.get('name')+" Version " +povType.get('version')
    text  = text +'\n' + '        type: '+ typeText
    
    povFixture = povDetail.get('povFixture')
    text  = text +'\n' + '        fixture id: '+ povFixture.get('id')
    text  = text +'\n' + '        fixture name: '+ povFixture.get('name')

    povSettings = povDetail.get('povSettings')
    

text  = text +'\n' + 'device Fixture: ' +  str(deviceDefinition.get('fixtureId'))


uiUtils.displayMessage('Device parameters',text)