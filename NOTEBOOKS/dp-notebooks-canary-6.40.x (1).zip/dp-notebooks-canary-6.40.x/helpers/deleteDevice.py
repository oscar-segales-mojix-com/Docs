# -*- coding: utf-8 -*-
"""
Created on Fri Dec 21 10:58:31 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils


#%%
myEnv = chooseEnv.choosePremise()

#%% choose device
listOfDevices = deviceUtils.getDevicesOfPremise(myEnv)

listOfNames = []
for device in listOfDevices:
    nameOfDevice = device.get('name')
    if not nameOfDevice:
        nameOfDevice = "NoName"
    idOfDevice = device.get('id')
    str2Display =  idOfDevice + ":" +nameOfDevice
    listOfNames.append(str2Display)
    
deviceC = uiUtils.chooseWithMenu('Devices',listOfNames)
tmp = deviceC.split(':')
devideId = tmp[0]

#%%
deviceDefinition = deviceUtils.deleteDeviceNPovById(myEnv,devideId)
#%%

