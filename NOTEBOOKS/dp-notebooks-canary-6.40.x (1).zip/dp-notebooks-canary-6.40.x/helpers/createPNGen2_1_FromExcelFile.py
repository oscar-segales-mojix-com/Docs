# -*- coding: utf-8 -*-
"""
Created on Fri Jun 15 10:08:16 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils


import pandas as pd
import numpy as np
import os
#%%
myEnv = chooseEnv.choosePremise()

#%% Choose file
# powerNodes file definition:
# Mandatory for PowerNode creation: one column should be named "MAC"
# To use this file with the other utils, it should be formmatted like:
# |powerNode|MAC|QRCode|
# first row is always the name (row name does not affect)
# "MAC" & "QRCode" row position can be changed 
initialdirectory = ""

file_name = uiUtils.getOneFile(initialdirectory,"Select PowerNodes Excel file",(("xlsx files","*.xlsx"),("all files","*.*")))

#%% Load File
df = pd.read_excel(file_name)
baseName = os.path.dirname(file_name)

for index, row in df.iterrows():
    name = row[0]
    pnMac = row["MAC"]
    deviceUtils.createPowerNode(myEnv,pnMac)

