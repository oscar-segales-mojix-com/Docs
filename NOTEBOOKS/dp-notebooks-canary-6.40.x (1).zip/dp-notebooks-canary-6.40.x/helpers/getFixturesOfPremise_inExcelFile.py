# -*- coding: utf-8 -*-
"""
Created on Tue Jan  8 14:52:18 2019

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import fixturesUtils as fixturesUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils

import pandas as pd

#%%
myEnv = chooseEnv.choosePremise()

#%% choose device
fixtureslist = fixturesUtils.getFixturesOfPremise(myEnv)
#%%
premiseId = myEnv.get('PremiseId')
df = pd.DataFrame(columns=['id','name','attributes','QRCode','locationId','locationLevel','areaCode','floorId','premiseId'])
for fix in fixtureslist:
    id = fix.get('id')
    QRCode = 'FIXT={\"sgln\":\"' + id +'\"}'
    
    df = df.append({'id':id,'name':fix.get('name'),'attributes':fix.get('attributes'),'QRCode':QRCode,'locationId':fix.get('locationId'),'locationLevel':fix.get('locationLevel'),'areaCode':fix.get('areaCode'),'floorId':str(fix.get('floorId')),'premiseId':premiseId} , ignore_index=True)

#Fixture	          QRCode
#3663328.01000.1001	  FIXT={"sgln":"3663328.01000.1001"}
#3663328.01000.1002	  FIXT={"sgln":"3663328.01000.1002"}

#%%
defaultName = premiseId + "_fixtures.xlsx"
sheetName = premiseId + "_fixtures"
fname = uiUtils.saveOneFile(".",defaultName,"Select output excel file",(("excel files","*.xlsx"),("all files","*.*")))
if fname is None:
    # skip by user
    print('skip by user')
        
elif (not fname):
    print('skip by user')
        
else:
    df.to_excel(fname,sheet_name=sheetName,index=False)

