# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 20:26:50 2018

@author: jlinotte
"""

#%% createPOS

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils

import json

#%%
myEnv = chooseEnv.choosePremise()
#%%
myForm = uiUtils.inputWithForm('POS definition',['IP','ID','NAME','FIXTURE'])

posIp = myForm.get('IP')
posID = myForm.get('ID') # NUMBER
posName = myForm.get('NAME')
posFixture = myForm.get('FIXTURE') 
# POV part; generated 
povId = posName+'_1'
povName = posName+'_1'
                        
#%%
deviceUtils.createPOS(myEnv,posIp,posID,posName)
povUtils.createPovForPOS(myEnv,povId,povName,posFixture,posID)
deviceUtils.enableDevice(myEnv,posID)

#%%
mappingJson= []
answer=uiUtils.askQuestionYesNo('Generate mapping','Do you want to generate mapping information ?')
if answer is None:
    # skip
    print('skip by user')
    
elif (answer=='no'):
    #skip
    print('skip by user')
 
else :    
    import copy
    # not mandatory
    
    from datetime import timezone, datetime
    ts = int(datetime.now(tz=timezone.utc).timestamp() * 1000)
    
    templateJson =     {
           "assets": [
               #"povName:POS_MODE"
           ],
           "header": {
               "bizStep": "urn:epcglobal:cbv:bizstep:retail_selling",
               "disposition": "urn:epcglobal:cbv:disp:retail_sold",
               "eventTime": 1,
               "action": "OBSERVE",
               "bizLocation": "urn:epc:id:sgln:fixture"
           }
       }
    
    myForm = uiUtils.inputWithForm('POS POS_PAYMENT definition',['bizStep','disposition','bizLocation'])
    paymentjson = copy.deepcopy(templateJson)
    paymentjson["assets"].append(povName+":POS_PAYMENT")
    tmp = paymentjson["header"]
    tmp['bizStep'] = myForm.get('bizStep')
    tmp['disposition'] = myForm.get('disposition')
    tmp['bizLocation'] = myForm.get('bizLocation')
    tmp['eventTime'] = ts
    
    
    myForm = uiUtils.inputWithForm('POS POS_RETURN definition',['bizStep','disposition','bizLocation'])
    returnjson = copy.deepcopy(templateJson)
    returnjson["assets"].append(povName+":POS_RETURN")
    tmp = returnjson["header"]
    tmp['bizStep'] = myForm.get('bizStep')
    tmp['disposition'] = myForm.get('disposition')
    tmp['bizLocation'] = myForm.get('bizLocation')
    tmp['eventTime'] = ts
    
    
    myForm = uiUtils.inputWithForm('POS POS_READ_ONLY" definition',['bizStep','disposition','bizLocation'])
    readonlyjson = copy.deepcopy(templateJson)
    readonlyjson["assets"].append(povName+":POS_READ_ONLY")
    tmp = readonlyjson["header"]
    tmp['bizStep'] = myForm.get('bizStep')
    tmp['disposition'] = myForm.get('disposition')
    tmp['bizLocation'] = myForm.get('bizLocation')
    tmp['eventTime'] = ts
    
    
    mappingJson = [paymentjson , returnjson, readonlyjson]

#%% display
if mappingJson :
    windowTitle = "Append HUB -povIdModeToEpcisEventMapping.json-" 
    text = json.dumps(mappingJson,indent=4)
    uiUtils.displayMessage(windowTitle,text)
#%% save
if mappingJson :
    defaultName = povName + "_povIdModeToEpcisEventMapping.json"
    fname = uiUtils.saveOneFile(".",defaultName,"Select output json file",(("json files","*.json"),("all files","*.*")))
    if fname is None:
        # skip by user
        print('skip by user')
        
    elif (not fname):
        print('skip by user')
        
    else:
        with open(fname, 'w') as outfile:
            json.dump(mappingJson, outfile,indent=4)

#%% example
# povIdModeToEpcisEventMapping.json
#jsonFile = [
#    {
#       "assets": [
#           "povName:POS_PAYMENT"
#       ],
#       "header": {
#           "bizStep": "urn:epcglobal:cbv:bizstep:retail_selling",
#           "disposition": "urn:epcglobal:cbv:disp:retail_sold",
#           "eventTime": 1518185517717,
#           "action": "OBSERVE",
#           "bizLocation": "urn:epc:id:sgln:fixture"
#       }
#   },
#   {
#       "assets": [
#           "povName:POS_RETURN"
#       ],
#       "header": {
#           "bizStep": "urn:epcglobal:cbv:bizstep:shipping",
#           "disposition": "urn:epcglobal:cbv:disp:in_transit",
#           "eventTime": 1518185517717,
#           "action": "OBSERVE",
#           "bizLocation": "urn:cxi:site:loc:DC"
#       }
#   },
#   {
#       "assets": [
#           "povName:POS_READ_ONLY"
#       ],
#       "header": {
#           "bizStep": "urn:epcglobal:cbv:bizstep:cycle_counting",
#           "disposition": "urn:epcglobal:cbv:disp:sellable_accessible",
#           "eventTime": 1518185517717,
#           "action": "OBSERVE",
#           "bizLocation": "urn:epc:id:sgln:fixture"
#       }
#   }
#]
