# -*- coding: utf-8 -*-
"""
Created on Mon Jan  7 15:46:08 2019

@author: jlinotte
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Dec 21 10:58:31 2018

@author: jlinotte
"""

#%%

from libConfUtils import chooseEnv as chooseEnv
from libConfUtils import deviceUtils as deviceUtils
from libConfUtils import povUtils as povUtils
from libConfUtils import uiUtils as uiUtils
from libConfUtils import premiseNhubUtils as premiseNhubUtils

#%%
myEnv = chooseEnv.choosePremise()

#%% choose device
listOfDevices = deviceUtils.getPrintersOfPremise(myEnv)

listOfNames = []
for device in listOfDevices:
    nameOfDevice = device.get('name')
    if not nameOfDevice:
        nameOfDevice = "NoName"
    idOfDevice = device.get('id')
    str2Display =  idOfDevice + ":" +nameOfDevice
    listOfNames.append(str2Display)
    
deviceC = uiUtils.chooseWithMenu('Printers',listOfNames)
tmp = deviceC.split(':')
deviceId = tmp[0]

#%%
deviceDefinition = deviceUtils.getPrinter(myEnv,deviceId)
#%%
text = "Premise: " + str(myEnv.get('PremiseCode'))
text  = text +'\n' + 'Printer ID: ' +  deviceId
text  = text +'\n' + 'Printer IP: ' +  deviceDefinition.get('uri')
text  = text +'\n' + 'Printer MAC: ' +  deviceDefinition.get('mac')
text  = text +'\n' + 'Printer Fixture: ' +  deviceDefinition.get('fixtureId')


uiUtils.displayMessage('Printer parameters',text)


