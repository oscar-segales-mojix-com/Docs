# dp-notebooks
Jupyther notebooks to help to configure ShopCx

## confUtils

collection a python (3.x) scripts & Jupyter notebooks for ShopCX configuration changes
dev with Conda (using spyder)
Tkinter may need to be installed


### Add a new environnment.
edit /libConfUtils/env.xls
in a new line, enter environnment friendly name and url
compute the token for basic authentication ( https://www.blitter.se/utils/basic-authentication-header-generator/) 
save the file

### Active Request logs:
- edit dp-notebooks\libConfUtils\xx.py (replace xx with the file where you want to activate logs)
- change to "displayLogs = True"
- NOTE: all requests have not been refactored

### List of scripts and comments:
-
- directHubAPI : api to communicate directly with the HUB

